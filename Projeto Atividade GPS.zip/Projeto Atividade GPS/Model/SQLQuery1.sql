CREATE DATABASE info
CREATE TABLE [dbo].[tbinfoempresa] (
    [cod_empresa]        INT           IDENTITY (1, 1) NOT NULL,
    [cnpj]               VARCHAR (50)  NOT NULL,
    [nome_empresarial]   VARCHAR (250) NOT NULL,
    [nome_fantasia]      VARCHAR (250) NOT NULL,
    [data_de_abertura]   VARCHAR (250) NOT NULL,
    [desc_atividade]     VARCHAR (250) NOT NULL,
    [uf]                 VARCHAR (2)   NOT NULL,
    [logradouro]         VARCHAR (250) NOT NULL,
    [cidade]             VARCHAR (250) NOT NULL,
    [numero]             VARCHAR (10)  NOT NULL,
    [complemento]        VARCHAR (250) NOT NULL,
    [cep]                VARCHAR (25)  NOT NULL,
    [bairro]             VARCHAR (250) NOT NULL,
    [situacao_cadastral] VARCHAR (20)  NOT NULL,
    PRIMARY KEY CLUSTERED ([cod_empresa] ASC)
);

