﻿using DllConsultaCNPJ;
using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsForms
{
    public partial class frmFormulario : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=ACER-ALBERTO\\SQLEXPRESS;Initial Catalog=info;Integrated Security=True");
        SqlCommand comando = new SqlCommand();
        public frmFormulario() 
        {
            InitializeComponent();
        }

        private void frmConsultaCNPJ_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'infoDataSet.tbinfoempresa'. Você pode movê-la ou removê-la conforme necessário.
            this.tbinfoempresaTableAdapter1.Fill(this.infoDataSet.tbinfoempresa);
            comando.Connection = conn;
            CarregaCaptcha();
            txtRazao.Enabled = false;
            txtFantasia.Enabled = false;
            txtDataAbertura.Enabled = false;
            txtAtividadeEconomeica.Enabled = false;
            txtUF.Enabled = false;
            txtLogradouro.Enabled = false;
            txtCidade.Enabled = false;
            txtNumero.Enabled = false;
            txtComplemento.Enabled = false;
            txtCEP.Enabled = false;
            txtBairro.Enabled = false;
            txtSituacaoCadastral.Enabled = false;


        }

        private void btConsultar_Click(object sender, EventArgs e)
        {
            ConsultaCNPJ();
        }

        private void btTrocarImagem_Click(object sender, EventArgs e)
        {
            CarregaCaptcha();
        }


        private async void CarregaCaptcha() 
        {
            LimpaCamposCaptcha();

            await Task.Run(() => 
            {
                BloqueiaBotaoTrocaImagem(true); 

                if (ConsultaCNPJReceita.GetCaptcha(picLetras) == false)
                {
                    MessageBox.Show(ConsultaCNPJReceita.Mensagem); 
                }

                BloqueiaBotaoTrocaImagem(false); 
            });
        }

        private void LimpaCamposCaptcha()
        {
            Invoke((MethodInvoker)(() =>
            {
                txtLetras.Text = "";
                txtLetras.Focus();
            }));
        }

        private void BloqueiaBotaoTrocaImagem(bool Bloquear)
        {
            Invoke((MethodInvoker)(() => {
                if (Bloquear == true)
                {
                    btTrocarImagem.Enabled = false;
                    btTrocarImagem.Text = "Carregando";
                }else
                {
                    btTrocarImagem.Enabled = true;
                    btTrocarImagem.Text = "Alterar Imagem";
                }
            }));
        }

        private void BloqueiaBotaoConsultaCNPJ(bool Bloquear)
        {
            Invoke((MethodInvoker)(() => {
                if (Bloquear == true)
                {
                    btConsultar.Enabled = false;
                    btConsultar.Text = "Carregando";
                }
                else
                {
                    btConsultar.Enabled = true;
                    btConsultar.Text = "Consultar CNPJ";
                }
            }));
        }

        private async void ConsultaCNPJ()
        {
            if (ConsultaCNPJReceita.ValidaCampos(txtCNPJ.Text, txtLetras.Text) == false)
            {
                MessageBox.Show(ConsultaCNPJReceita.Mensagem);
                return;
            }


            await Task.Run(() => 
            {
                BloqueiaBotaoConsultaCNPJ(true); 

                if (ConsultaCNPJReceita.Consulta(txtCNPJ.Text, txtLetras.Text))
                    CarregaDadosNoFormulario();
                else
                    MessageBox.Show(ConsultaCNPJReceita.Mensagem);

                BloqueiaBotaoConsultaCNPJ(false); 
                CarregaCaptcha(); 
            });
        }


        private void CarregaDadosNoFormulario()
        {
            Invoke((MethodInvoker)(() =>
            {
                Empresa empresaConsultada;

                empresaConsultada = ConsultaCNPJReceita.Empresa;

                txtRazao.Text = empresaConsultada.RazaoSocial;
                txtFantasia.Text = empresaConsultada.NomeFantasia;
                txtAtividadeEconomeica.Text = empresaConsultada.AtividadeEconomicaPrimaria;
                txtLogradouro.Text = empresaConsultada.Endereco;
                txtNumero.Text = empresaConsultada.Numero;
                txtComplemento.Text = empresaConsultada.Complemento;
                txtBairro.Text = empresaConsultada.Bairro;
                txtCidade.Text = empresaConsultada.Cidade;
                txtUF.Text = empresaConsultada.UF;
                txtCEP.Text = empresaConsultada.CEP;
                txtSituacaoCadastral.Text = empresaConsultada.SituacaoCadastral;
                txtDataAbertura.Text = empresaConsultada.DataAbertura;

            }));
        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void Label21_Click(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            comando.CommandText = " INSERT INTO tbinfoempresa(cnpj,nome_empresarial,nome_fantasia,data_de_abertura,desc_atividade,uf,logradouro,cidade,numero,complemento,cep,bairro,situacao_cadastral) VALUES ('" + txtCNPJ.Text + "', '" + txtRazao.Text + "', '"
            + txtFantasia.Text + "', '" + txtDataAbertura.Text + "', '" + txtAtividadeEconomeica.Text + "', '" + txtUF.Text + "', '" + txtLogradouro.Text + "', '"+ txtCidade.Text  + txtNumero.Text + "', '" + txtComplemento.Text + "', '" + txtCEP.Text + "', '" + txtBairro.Text + "', '" + txtSituacaoCadastral.Text + "', '"+"')";
            comando.ExecuteNonQuery();
            MessageBox.Show("Empresa cadastrada com sucesso!");
            conn.Close();
        }

        private void Label7_Click(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {

        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void TxtRazao_TextChanged(object sender, EventArgs e)
        {

        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void TxtCNPJ_TextChanged(object sender, EventArgs e)
        {

        }

        private void TbinfoempresaDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
